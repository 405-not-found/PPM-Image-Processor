#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include "constants.h"
#include "image.h"

using namespace std;

void readImage(istream &is, Image &imI)
{
    string HeaderNumber;
     unsigned char bit;
    // Read Headernumber
    is >> HeaderNumber;

    // Read width, height in to imI
    is >> imI.w;
    is >> imI.h;

    // Read Maxnumber
    int maxnumber;
    is >> maxnumber;
    is >> noskipws;
    is >> bit;

    // Read the RGB values and store them in the image structure
    for (unsigned int j = 0; j < imI.h; ++j)
    {
        for (unsigned int i = 0; i < imI.w; ++i)
        {
            Rgb &pixel = imI.image[i][j];
            is >> pixel.red;
            is >> pixel.green;
            is >> pixel.blue;
        }
    }
}

void writeImage(ostream &os, const Image &imI)
{
    os << "P6" << endl;
    cout << "P6" << endl;

    // Write width, height in to imI
    os << imI.w << ' ' << imI.h << endl;
    cout << imI.w << ' ' << imI.h << endl;

    // Write Maxnumber
    int maxnumber = 255;
    os << maxnumber << endl;
    cout << maxnumber << endl;

    // Read pixel data
    for (unsigned int j = 0; j < imI.h; j++)
    {
        for (unsigned int i = 0; i < imI.w; i++)
        {
            const Rgb &pixel = imI.image[i][j];
            os << pixel.red;
            os << pixel.green;
            os << pixel.blue;
            cout << pixel.red;
            cout << pixel.green;
            cout << pixel.blue;
        }
    }
}

void verticalFlip(const Image &imI, Image &imJ)
{

    // Operating verticalFlip
    imJ.w = imI.w;
    imJ.h = imI.h;
    const int height = imI.h;
    int w = imI.w;
    for (int j = 0; j < height; j++)
    {
        for (int i = 0; i < w; i++)
        {
            imJ.image[i][j] = imI.image[i][height - j - 1];
        }
    }
}

void rotate90(const Image &imI, Image &imJ)
{
    // Find the width and height of the input image first
    int Jheight = imI.w;
    int Jwidth = imI.h;
    
    // Operating Rotation of 90 degrees
    for (int j = 0; j < Jheight; ++j)
    {
        for (int i = 0; i < Jwidth; ++i)
        {
            imJ.image[i][j] = imI.image[j][Jheight-1-i];
        }
    }
}



void intensityInversion(const Image &imI, Image &imJ)
{
    // Find the width and height of the input image first
    int w = imI.w;
    int h = imI.h;

    // Operating Intensity inversion
    for (int j = 0; j < h; ++j)
    {
        for (int i = 0; i < w; ++i)
        {
            const Rgb &pixel = imI.image[i][j];
            Rgb newpixel = {0, 0, 0};
            newpixel.red = 255 - pixel.red;
            newpixel.green = 255 - pixel.green;
            newpixel.blue = 255 - pixel.blue;
            imJ.image[i][j] = newpixel;
        }
    }
}

// Aggregating function: Maximum value
unsigned char max(const unsigned char values[3][3])
{
    unsigned char maxValue = values[0][0];
    for (int i = 0; i < 3; ++i)
    {
        for (int j = 0; j < 3; ++j)
        {
            if (values[i][j] > maxValue)
            {
                maxValue = values[i][j];
            }
        }
    }
    return maxValue;
}

// Aggregating function: Mean value
unsigned char mean(const unsigned char values[3][3])
{
    unsigned int sum = 0;
    for (int i = 0; i < 3; ++i)
    {
        for (int j = 0; j < 3; ++j)
        {
            sum += values[i][j];
        }
    }
    unsigned char meanValue = static_cast<unsigned char>(sum / 9);
    return meanValue;
}

// Aggregating function: Median value
unsigned char median(const unsigned char values[3][3])
{
    unsigned char sortedValues[9];
    int index = 0;
    for (int i = 0; i < 3; ++i)
    {
        for (int j = 0; j < 3; ++j)
        {
            sortedValues[index++] = values[i][j];
        }
    }
    sort(begin(sortedValues), end(sortedValues));
    unsigned char medianValue = sortedValues[4];
    return medianValue;
}

typedef unsigned char (*Agg)(const unsigned char values[3][3]);

// Implementing the filter function
void filter(const Image &imI, Image &imJ, Agg f)
{
    // Find the width and height of the input image
    int w = imI.w;
    int h = imI.h;

    // Apply filtering operation
    for (int j = 0; j < h; ++j)
    {
        for (int i = 0; i < w; ++i)
        {
            // Prepare the neighborhood values arrays for each color channel
            unsigned char neighborhoodRed[3][3];
            unsigned char neighborhoodGreen[3][3];
            unsigned char neighborhoodBlue[3][3];

            // Extract the pixel values in the neighborhood for each color channel
            // Extract the pixel values in the neighborhood for each color channel
            for (int y = -1; y <= 1; ++y)
            {
                for (int x = -1; x <= 1; ++x)
                {
                    int posX = i + x;
                    int posY = j + y;

                    if (posX >= 0 && posX < w && posY >= 0 && posY < h)
                    {
                        neighborhoodRed[x + 1][y + 1] = imI.image[posX][posY].red;
                        neighborhoodGreen[x + 1][y + 1] = imI.image[posX][posY].green;
                        neighborhoodBlue[x + 1][y + 1] = imI.image[posX][posY].blue;
                    }
                    else
                    {
                        neighborhoodRed[x + 1][y + 1] = 0;
                        neighborhoodGreen[x + 1][y + 1] = 0;
                        neighborhoodBlue[x + 1][y + 1] = 0;
                    }
                }
            }

            // Apply the aggregating function to each color channel separately
            unsigned char aggregatedRed = f(neighborhoodRed);
            unsigned char aggregatedGreen = f(neighborhoodGreen);
            unsigned char aggregatedBlue = f(neighborhoodBlue);

            // Assign the aggregated values to the corresponding channels of the output pixel
            imJ.image[i][j].red = aggregatedRed;
            imJ.image[i][j].green = aggregatedGreen;
            imJ.image[i][j].blue = aggregatedBlue;
        }
    }
}

// Check if the file exits
bool file_exists(const string &filename)
{
    ifstream file(filename);
    return file.good();
}

// Check if the file is a ppm file
bool is_ppm_file(const string &filename)
{
    if (filename.length() < 4)
    {
        return false;
    }

    string extension = filename.substr(filename.length() - 4, 4);

    return extension == ".ppm";
}

int main(int argc, char *argv[])
{
    vector<string> args(argv + 1, argv + argc);

    // Check if --help or -h is present among the arguments, if exits, print the help message
    for (const auto &arg : args)
    {
        if (arg == "--help" || arg == "-h")
        {
            cout << HELP_MESSAGE << endl;
            return 0;
        }
    }

    // Process other options
    string input_file;
    string output_file;
    string transformation;

    for (long unsigned int i = 0; i < args.size(); ++i)
    {
        if (args[i] == "-i" && i + 1 < args.size())
        {
            input_file = args[++i]; // The next argument is the input file
        }
        else if (args[i] == "-o" && i + 1 < args.size())
        {
            output_file = args[++i]; // The next argument is the output file
        }
        else if (args[i] == "-t" && i + 1 < args.size())
        {
            transformation = args[++i]; // The next argument is the transformation
        }
    }

    // Validate the input file exits or not
    if (!file_exists(input_file))
    {
        cout << FILE_NOT_EXIST_ERROR << endl;
        return 0;
    }
    // Validate if the input file is a ppm file
    if (!is_ppm_file(input_file))
    {
        cout << FILE_TYPE_ERROR << endl;
        return 0;
    }
    // Check if the transformation is valid
    if (!(transformation == "verticalFlip" ||
          transformation == "rotate90" ||
          transformation == "intensityInversion" ||
          transformation == "maxFilter" ||
          transformation == "meanFilter" ||
          transformation == "medianFilter"))
    {
        cout << TRANSFORM_ERROR << endl;
        return 0;
    }

    // Open input file and readImage to inputImage
    ifstream inputFile(input_file, ios::binary);
    Image inputImage;

    readImage(inputFile, inputImage);
    inputFile.close();

    Image outputImage = inputImage;

    // Apply the specified transformation
    if (transformation == "verticalFlip")
    {
        verticalFlip(inputImage, outputImage);
    }
    else if (transformation == "rotate90")
    {
        rotate90(inputImage, outputImage);
    }
    else if (transformation == "intensityInversion")
    {
        intensityInversion(inputImage, outputImage);
    }
    else if (transformation == "maxFilter")
    {
        filter(inputImage, outputImage, max);
    }
    else if (transformation == "meanFilter")
    {
        filter(inputImage, outputImage, mean);
    }
    else if (transformation == "medianFilter")
    {
        filter(inputImage, outputImage, median);
    }

    // Save the resulting image to an output file
    ofstream outputFile(output_file, ios::binary);
    writeImage(outputFile, outputImage);
    outputFile.close();

    return 0;
}